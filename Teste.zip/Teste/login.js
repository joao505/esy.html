// login.js
const usernameInput = document.getElementById('name');
const phoneInput = document.getElementById('phone');
const loginBtn = document.getElementById('login-btn');
const loginForm = document.getElementById('login-form');

let points = 0;

function validateInputs() {
  const isUsernameValid = usernameInput.value.length >= 4;
  const isPhoneValid = phoneInput.value.length >= 8;
  loginBtn.disabled = !(isUsernameValid && isPhoneValid);
}

usernameInput.addEventListener('input', validateInputs);
phoneInput.addEventListener('input', validateInputs);

usernameInput.addEventListener('keypress', function(event) {
  if (event.key === 'Enter') {
    event.preventDefault();
    if (!loginBtn.disabled) {
      loginBtn.click();
    }
  }
});

loginForm.addEventListener('submit', function(event) {
  event.preventDefault();

  if (usernameInput.value.length >= 4 && phoneInput.value.length >= 8) {
    const formData = new FormData();
    formData.append('username', usernameInput.value);
    formData.append('phone', phoneInput.value);
    formData.append('points', points);

    fetch('saveUserData.php', {
      method: 'POST',
      body: formData
    })
    .then(response => response.text().then(text => ({ ok: response.ok, text })))
    .then(({ ok, text }) => {
      if (ok) {
        alert('Dados salvos com sucesso!');
        window.location = 'index.html';
      } else {
        throw new Error(text);
      }
    })
    .catch(error => {
      console.error('Erro:', error);
      alert('Ocorreu um erro ao salvar os dados: ' + error.message);
    });
  } else {
    alert('Por favor, preencha corretamente todos os campos.');
  }
});
