document.addEventListener('DOMContentLoaded', function () {
  const pointsDisplay = document.getElementById('points-display');
  const imageContainer = document.getElementById('image-container');
  const aiButton = document.getElementById('ai-button');
  const notAiButton = document.getElementById('not-ai-button');

  let points = 0;
  let images = [];
  let currentImageIndex = 0;

  // Função para carregar imagens das pastas
  function loadImages() {
    // Imagens geradas por IA
    const aiImages = Array.from({ length: 10 }, (_, i) => `fotos IA/IA${i + 1}.jpg`).map(src => ({ src, isAI: true }));

    // Imagens não geradas por IA
    const notAiImages = Array.from({ length: 10 }, (_, i) => `fotos nIA/nao+IA${i + 1}.jpg`).map(src => ({ src, isAI: false }));

    images = [...aiImages, ...notAiImages];
    shuffleImages();
    displayNextImage();
  }

  // Embaralhar as imagens
  function shuffleImages() {
    for (let i = images.length - 1; i > 0; i--) {
      const j = Math.floor(Math.random() * (i + 1));
      [images[i], images[j]] = [images[j], images[i]];
    }
  }

  // Exibir a próxima imagem
  function displayNextImage() {
    if (currentImageIndex >= images.length) {
      currentImageIndex = 0;
    }

    const { src, isAI } = images[currentImageIndex];
    imageContainer.innerHTML = `<img src="${src}" class="image ${isAI ? 'ai' : 'not-ai'}" alt="Imagem">`;
  }

  // Verificar a resposta do jogador
  function checkAnswer(isAiSelected) {
    const isAiImage = images[currentImageIndex].isAI;

    if ((isAiSelected && isAiImage) || (!isAiSelected && !isAiImage)) {
      points++;
      pointsDisplay.textContent = `Pontos: ${points}`;
      currentImageIndex++;
      if (points >= 200) {
        window.location = 'parabens.html';
      } else {
        displayNextImage();
      }
    } else {
      if (isAiImage) {
        window.location = 'errou1.html';
      } else {
        window.location = 'errou0.html';
      }
    }
  }

  // Adicionar event listeners aos botões
  aiButton.addEventListener('click', () => checkAnswer(true));
  notAiButton.addEventListener('click', () => checkAnswer(false));

  // Inicializar o jogo ao carregar a página
  loadImages();
});
