<?php
$folder = isset($_GET['folder']) ? $_GET['folder'] : '';
if ($folder) {
    $directory = __DIR__ . '/' . $folder;
    $files = array_diff(scandir($directory), array('..', '.'));
    $images = array_map(function($file) use ($folder) {
        return $folder . '/' . $file;
    }, $files);

    echo json_encode($images);
} else {
    echo json_encode([]);
}
?>
