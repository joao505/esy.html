<!DOCTYPE html>
<html lang="pt-br">

<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <link rel="shortcut icon" href="ícone+IA.png" type="image/x-icon">
  <link rel="stylesheet" href="style.css">
  <title>Ranking</title>
</head>

<body>
  <button class="Início" type="button" onclick="window.location = 'login.html'">Inicio</button>
  <h1>Ranking de Pontuação</h1>
  <table>
    <thead>
      <tr>
        <th>Nome</th>
        <th>Pontos</th>
      </tr>
    </thead>
    <tbody>
      <?php
      $file_path = 'userdata.txt';
      if (file_exists($file_path)) {
        $file = fopen($file_path, 'r');
        $users = [];
        while (($line = fgets($file)) !== false) {
          // Remover espaços em branco e quebras de linha
          $line = trim($line);
          if (empty($line)) {
            continue; // Pular linhas vazias
          }
          
          $parts = explode(", ", $line);
          if (count($parts) !== 3) {
            continue; // Pular linhas malformadas
          }

          $name_part = explode(": ", $parts[0]);
          $points_part = explode(": ", $parts[2]);
          if (count($name_part) !== 2 || count($points_part) !== 2) {
            continue; // Pular partes malformadas
          }

          $name = $name_part[1];
          $points = (int)$points_part[1];
          $users[] = ['name' => $name, 'points' => $points];
        }
        fclose($file);

        usort($users, function($a, $b) {
          return $b['points'] - $a['points'];
        });

        foreach ($users as $user) {
          echo "<tr><td>{$user['name']}</td><td>{$user['points']}</td></tr>";
        }
      } else {
        echo "<tr><td colspan='2'>Nenhum dado disponível</td></tr>";
      }
      ?>
    </tbody>
  </table>
</body>

</html>
