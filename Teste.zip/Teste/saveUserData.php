<?php
// Permitir solicitações de qualquer origem (CORS)
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: POST');
header('Access-Control-Allow-Headers: Content-Type');

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $username = $_POST['username'] ?? 'teste';
    $phone = $_POST['phone'] ?? '12345678';
    $points = $_POST['points'] ?? 0;

    // Validar e processar os dados como necessário
    $data = "Nome: $username, Telefone: $phone, Pontos: $points\n";

    // Caminho do arquivo
    $file_path = 'userdata.txt';

    // Verificar se o diretório é gravável
    if (is_writable(dirname($file_path))) {
        // Tente abrir o arquivo para escrita (append)
        $file = fopen($file_path, 'a');

        if ($file) {
            // Escreva os dados no arquivo
            fwrite($file, $data);
            fclose($file);
            http_response_code(200); // Resposta de sucesso
            echo 'Dados salvos com sucesso!';
        } else {
            // Se não conseguir abrir o arquivo, envie um código de erro e uma mensagem
            error_log("Erro ao abrir o arquivo $file_path para escrita.");
            http_response_code(500); // Erro interno do servidor
            echo 'Erro ao salvar dados no servidor: não foi possível abrir o arquivo.';
        }
    } else {
        // Diretório não é gravável
        error_log("Diretório não é gravável: " . dirname($file_path));
        http_response_code(500); // Erro interno do servidor
        echo 'Erro ao salvar dados no servidor: diretório não é gravável.';
    }
} else {
    http_response_code(405); // Método não permitido
    echo 'Método não permitido';
}
?>
